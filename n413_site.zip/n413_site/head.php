<?php
/**
 * Author: Froylan Avila
 * Date: 9/17/2020
 * File: head.php
 * Description:
 */
?>
<!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
            <title>Full Stack Amp Jam Site Project</title>
            <link href="css/bootstrap.min.css" rel="stylesheet">

            <script src="js/jquery-3.4.1.min.js" type="application/javascript"></script>
            <script src="js/bootstrap.min.js" type="application/javascript"></script>
            <script src="js/bootstrap.min.js.map" type="application/javascript"></script>
            <script>
                function navbar_update(this_page){
                    $("#"+this_page+"_item")
                    $("#"+this_page+"_link").append(' <span class="sr-only">(current)</span>');
                }
            </script>
        </head>
        <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <!-- <nav class="navbar navbar-expand-lg navbar-dark"> style="background-color:#CCEEFF;"> -->
            <a class="navbar-brand" href="index.php">AMP JAM SITE</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="list.php">The List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="form.php">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
