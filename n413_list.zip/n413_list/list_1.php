<?php
/**
 * Author: Froylan Avila
 * Date: 9/3/2020
 * File: list_1.php
 * Description:
 */

include("n413connect.php");
$sql = "SELECT item FROM `list`";
$result = mysqli_query($link, $sql);
while ($row = mysqli_fetch_array($result, MYSQLI_BOTH)){
    echo $row["item"].'<br/>';
}
?>